--4. INSERCIÓN DE DATOS 
--4.1.Insertar varias filas en cada una de las tablas de forma que todas las tablas, particiones y subparticiones contengan alguna fila.  
--En la tabla ABDXX_ONG, la columna código ha de ser un número secuencial obtenido automáticamente a partir de una secuencia. 
-- Crear la secuencia llamada ABDXX_CO, tal que comenzando por el cero (0), genere identificadores de 2 en 2, hasta un valor máximo de 500 y sin ciclos.  

--Crear secuencia.
	CREATE SEQUENCE ABD02_CO
		START WITH 0
		INCREMENT BY 2
		MINVALUE 0 
		MAXVALUE 500;
    
  --Para utilizar lo anterior ABD02_CO.nextVal
  
  --Datos tabla ONG.

ALTER TABLE ABD02_ONG
  DISABLE constraint ong_fk_trabajador;

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Salvemos al pato','pato@hotmail.es','123456780','Albacete','medioambiente','11111111A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Salvemos al panda','panda@hotmail.es','123456781','Alicante','medioambiente','22222222A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Naturaleza','natu@hotmail.es','123456782','Cuenca','medioambiente','33333333A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Vivienda','vivienda@hotmail.es','123456783','Lugo','inmigracion','44444444A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Lucha Humana','luhu@hotmail.es','123456784','Pontevedra','derechos humanos','55555555A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'SosHumano','Sos@hotmail.es','123456785','Granada','derechos humanos','66666666A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'Dehuma','Dehuma@hotmail.es','123456786','Malaga','inmigracion','77777777A');

INSERT INTO ABD02_ONG(codigo, nombre, email, telf, provincia, campo, responsable)
    VALUES(ABD02_CO.nextVal,'SegurAlimer','SegurAlimer@hotmail.es','123456787','Cadiz','Nutricion y Seguridad Alimentaria','88888888A');

COMMIT


--Datos tabla Trabajador.

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('11111111A','Marcos',0,'7/2/2014','N','25/1/1980','Empresario',37,950);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('22222222A','Elena',2,'7/3/2015','N','27/2/1978','Vendedora',40,1000);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('33333333A','Paco',4,'8/2/2012','N','05/02/1977','Locutor',41,1230);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('44444444A','Antonio',6,'1/2/2014','N','07/1/1980','Periodista',39,1020);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('66666666A','Concha',8,'7/5/2011','N','06/1/1950','Zapatera',48,1000);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('55555555A','Ana',10,'7/4/2010','N','25/1/1985','Conductora',50,700);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('77777777A','Lourdes',12,'7/5/2014','N','20/09/1970','Limpiadora',41,750);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('88888888A','Lucia',14,'7/2/2014','N','09/5/1980','Profesora',35,850);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('7777766A','AS',0,'7/2/2014','S','25/1/1980','Empresario',37,950);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('88888889A','EN',10,'7/2/2014','N','25/1/1980','Empresario',37,950);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('58799999E','TS',10,'7/2/2014','S','25/1/1980','Empresario',37,950);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('10101010A','Eusebio',0,'19/4/2012','N','10/4/1975','Escritora',32,900);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('12222222A','Marta',2,'17/5/2012','N','10/4/1975','Doctora',40,900);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('13333333A','Lazaro',2,'14/5/2015','N','10/4/1975','Pintor',38,1200);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('14444444A','Luisa',2,'11/5/1965','N','10/4/1975','Fontanera',35,1000);

INSERT INTO ABD02_TRABAJADOR(dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas, sueldo)
    VALUES('12121212A','Mariano',4,'11/5/1973','N','10/4/1975','Pintor',38,1050);


ALTER TABLE ABD02_ONG
  ENABLE CONSTRAINT ong_fk_trabajador;

COMMIT

--Datos tabla Proyecto.

INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(0,101,'Informar sobre el pato','ESPAÑA','Centro',25);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(0,102,'Recuperar humedales','ESPAÑA','a',78);



INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(2,201,'Informacion sobre el panda','ESPAÑA','OESTE',80);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(2,202,'Cultivo Bambu','ESPAÑA','Sur',70);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(2,203,'Recuperacion especies','ESPAÑA','Central',65);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(4,301,'Salvar bosques','ESPAÑA','Norte',85);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(6,401,'Ayuda a familias','ESPAÑA','Sur',45);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(6,402,'Viviendas sociales','ESPAÑA','b',50);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(8,501,'Ayuda personas problemas','ESPAÑA','extrarradio',78);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(10,601,'Reparto comida','ElSalvador','centro',98);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(12,701,'Ayuda busqueda hogar','Guinea','Sin determinar',99);




INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(14,801,'Seguridad Alimentos infantiles','ESPAÑA','Interior',38);


INSERT INTO ABD02_PROYECTO(ong, idproyecto, objetivo, pais, zona, numbeneficiarios)
        VALUES(14,802,'Vigilancia Alimentos 1ª necesidad','Senegal','Centro',78);

COMMIT

--Datos tabla accion.

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(0,101,1101,'Informacion en colegios');

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(0,101,1102,'Informar en la calle');

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(0,102,1201,'Concienciacion importancia humedales');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(0,102,1202,'Trabajo en humedales');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(2,201,2101,'Informacion en calles');

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(2,202,2202,'Busqueda financiacion');

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(2,202,2203,'Accion sobre el terreno');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(2,203,2301,'Comenzar por especies mas perjudicadas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(10,601,2601,'Reparto comida a personas en apuros');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(4,301,3301,'Recaudacion dinero');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(4,301,3302,'Busqueda personas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(4,301,3303,'Reforestacion');



INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(6,401,4101,'Buscar familias');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(6,401,4102,'Conocer familias');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(6,402,4201,'Preparacion Viviendas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(6,402,4202,'Reparto viviendas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(8,501,5101,'Conocer personas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(8,501,5102,'Integracion');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(12,701,7101,'Estudio recursos');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(12,701,7102,'Busqueda casa adecuada');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(14,801,8101,'Test supermercados');

INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(14,801,8102,'Test empresas');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(14,802,8201,'Reparto');


INSERT INTO ABD02_ACCION(ong, idproyecto, idaccion, descripcion)
    VALUES(14,802,8202,'Vigilancia');

COMMIT


--Datos tabla socio.

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('10101010A','Eusebio');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000000A','Jose');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000001A','Paco');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000002A','Marisa');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000003A','Pepe');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000004A','Luis');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000005A','Luis');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000006A','Rodolfo');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000007A','Beatriz');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000008A','Mauricio');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000009A','Jorge');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('30000010A','Lucia');


INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('55555555A','Ana');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('88888888A','Lucia');

INSERT INTO ABD02_SOCIO(dni, nombre)
    VALUES('77777777A','Lourdes');

COMMIT

--Datos tabla Colaboracionn.

  INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(8,'10101010A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(10,'10101010A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(12,'10101010A','04/06/2007',50);


INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(4,'30000000A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(4,'30000001A','04/06/2007',70);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(4,'30000002A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(4,'30000003A','04/06/2007',100);


INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(6,'30000004A','04/06/2007',40);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(6,'30000005A','04/06/2007',45);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(6,'30000006A','04/06/2007',25);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(2,'30000007A','04/06/2007',80);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(2,'30000008A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(2,'30000009A','04/06/2007',95);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(2,'30000010A','04/06/2007',300);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(12,'30000007A','04/06/2007',550);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(14,'30000007A','04/06/2007',450);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(10,'30000008A','04/06/2007',150);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(12,'30000008A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(14,'30000009A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(10,'30000010A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(12,'55555555A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(12,'88888888A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(10,'88888888A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(10,'77777777A','04/06/2007',50);

INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
    VALUES(14,'77777777A','04/06/2007',50);

COMMIT

-- Datos tabla participacion.

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(0,101,1101,'10101010A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(0,102,1201,'10101010A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(0,101,1102,'10101010A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(0,102,1202,'10101010A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,201,2101,'12222222A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,201,2101,'14444444A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,202,2202,'12222222A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,202,2203,'13333333A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,203,2301,'13333333A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(2,203,2301,'14444444A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(12,701,7101,'77777777A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(12,701,7102,'77777777A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(4,301,3301,'12121212A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(6,401,4101,'44444444A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(8,501,5102,'66666666A');

INSERT INTO ABD02_PARTICIPACION(ong, idproyecto, idaccion, trabajador)
    VALUES(14,801,8102,'88888888A');

COMMIT


