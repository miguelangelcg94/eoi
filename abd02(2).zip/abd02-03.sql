/* 3.2. Crear las tablas en el tablespace de datos teniendo en cuenta las siguientes indicaciones:  
ABDXX_SOCIO ha de estar organizada por índice (tabla IOT). 
ABDXX_ONG debe contener 3 particiones por hash según la columna código.
ABDXX_TRABAJADOR ha de organizarse en 2 particiones según el tipo de trabajador: una llamada CONTRATADO con los trabajadores contratados, y otra llamada VOLUNTARIO con los trabajadores voluntarios.  
ABDXX_PROYECTO, ABDXX_ACCION y ABDXX_PARTICIPACION deben ser almacenadas en un cluster llamado ABDXX_PAP.  
ABDXX_COLABORACION ha de estar particionada por rango de fechas de alta, con 2 particiones, una llamada COLAB_ANTIGUA con los socios dados de alta antes del 2010, y otra llamada COLAB_RECIENTE con los socios dados de alta a partir de 2010. A su vez, cada una de ellas debe contener 2 subparticiones por hash de la columna cuota. 
 */
--Crear tabla Socio

CREATE TABLE ABD02_SOCIO(
		dni 	VARCHAR(9) 	NOT NULL,
		nombre 	VARCHAR(50) 	NOT NULL,
		CONSTRAINT socio_pk PRIMARY KEY(dni)
	)
	ORGANIZATION INDEX
	TABLESPACE ABD02_DATOS
;

---Crear tabla ONG
CREATE TABLE ABD02_ONG(
		codigo 		NUMBER(5) 	NOT NULL,
		nombre 		VARCHAR(50) 	NOT NULL,
		email 		VARCHAR(50) 	NULL,
		telf		VARCHAR(9) 	NOT NULL,
		provincia    	VARCHAR(50)     NOT NULL,
		campo        	VARCHAR(50) 	NOT NULL,
		responsable    	VARCHAR(9) 	NOT NULL,
		CONSTRAINT ong_pk  PRIMARY KEY (codigo),
		CONSTRAINT clave_unique UNIQUE(responsable)
	)
	PARTITION BY HASH (codigo)
	PARTITIONS 3
	STORE IN (ABD02_DATOS);
  
  
  --Crear tabla trabajador

CREATE TABLE ABD02_TRABAJADOR( 
		dni 		VARCHAR(9) 	NOT NULL, 
		nombre 		VARCHAR(50) 	NOT NULL,
		ong 		NUMBER(5)  	NOT NULL,
		fechaingreso 	date 		NOT NULL,
		esvoluntario 	char(1) 	NOT NULL,
		nacimiento  	date 		NOT NULL,
		profesion 	VARCHAR(50) 	NOT NULL,
		horas     	number 		NOT NULL,
		sueldo 		number 		DEFAULT 0 NOT  NULL,
    Constraint trabajador_pk PRIMARY KEY (dni),
		Constraint trabajador_esvoluntario CHECK (esvoluntario IN('S', 'N')),
		Constraint trabajador_sueldo CHECK (sueldo>200),
		Constraint trabajador_horas CHECK (horas>0 and horas<=50),
		Constraint trabajador_fk_ong FOREIGN KEY (ong) REFERENCES ABD02_ONG(codigo)
	)
	PARTITION BY LIST (esvoluntario)
	(
    		PARTITION CONTRATADO VALUES ('N')
    			TABLESPACE ABD02_DATOS,
   		PARTITION VOLUNTARIO  VALUES ('S')
    			TABLESPACE ABD02_DATOS,
  		PARTITION DESCONOCIDO VALUES(DEFAULT)

);

ALTER TABLE ABD02_ONG
ADD Constraint ong_fk_trabajador FOREIGN KEY (responsable) 
  REFERENCES ABD02_TRABAJADOR(dni);
  
  --Crear Cluster e índice.
create cluster ABD02_PAP (ong number(5), idproyecto number(5))
TABLESPACE ABD02_DATOS;

CREATE INDEX id02_pap ON CLUSTER ABD02_PAP;


--Crear proyecto

CREATE TABLE ABD02_PROYECTO(
		ong 			NUMBER(5) 	NOT NULL,
		idproyecto 		NUMBER(5) 	NOT NULL,
		objetivo 		VARCHAR(50) 	NOT NULL,
		pais 			VARCHAR(50) 	NOT NULL,
		zona 			VARCHAR(50) 	NOT NULL,
		numbeneficiarios 	NUMBER,
		Constraint proyecto_pk primary key (ong, idproyecto),
		Constraint proyecto_fk_ong FOREIGN KEY (ong) REFERENCES ABD02_ONG(codigo)
	)
    CLUSTER ABD02_PAP(ong, idproyecto);
    

--Crear acción.

CREATE TABLE ABD02_ACCION(
		  ong 		NUMBER(5) 	NOT NULL,
		  idproyecto 	NUMBER(5) 	NOT NULL,
		  idaccion 	NUMBER(5) 	NOT NULL,
		  descripcion  	VARCHAR(50),
		  Constraint accion_pk primary key (ong, idproyecto, idaccion),
		  Constraint accion_fk_proyecto FOREIGN KEY (ong, idproyecto) REFERENCES ABD02_PROYECTO(ong, idproyecto)
	)
    CLUSTER ABD02_PAP (ong, idproyecto);
    

--Crear participación.

CREATE TABLE ABD02_PARTICIPACION(
	    ong 	NUMBER(5) 	NOT NULL,
	    idproyecto 	NUMBER(5) 	NOT NULL,
	    idaccion 	NUMBER(5) 	NOT NULL,
	    trabajador 	VARCHAR(9) 	NOT NULL,
	    Constraint participacion_pk primary key (ong, idproyecto, idaccion, trabajador),
	    Constraint participacion_fk_accion FOREIGN KEY (ong, idproyecto, idaccion) REFERENCES ABD02_ACCION(ong, idproyecto, idaccion),
	    Constraint trabajador_fk FOREIGN KEY (trabajador) REFERENCES ABD02_TRABAJADOR(dni)

	)
    CLUSTER ABD02_PAP (ong, idproyecto);

--Crear Colaboración.
CREATE TABLE ABD02_COLABORACION( 
		ong 		NUMBER(5) 	NOT NULL,
		socio 		VARCHAR(9) 	NOT NULL,
		fechaalta 	DATE 		NOT NULL,
		cuota 		NUMBER		DEFAULT 0 NULL,
		Constraint colaboracion_pk primary key (ong, socio),
		Constraint colaboracion_fk_ong FOREIGN KEY (ong) REFERENCES ABD02_ONG(codigo),
		Constraint colaboracion_fk_socio FOREIGN KEY (socio) REFERENCES ABD02_SOCIO(dni),
		Constraint colaboracion_cuota CHECK (cuota>0)
	)
	PARTITION BY RANGE(fechaalta)
		SUBPARTITION BY HASH (cuota)
    		SUBPARTITIONS 2 store in (ABD02_DATOS)
		(
			PARTITION COLAB_ANTIGUA
    				VALUES LESS THAN (TO_DATE('01/01/2010' ,'dd/mm/yyyy'))
  				TABLESPACE ABD02_DATOS,
			PARTITION COLAB_RECIENTE
    				VALUES LESS THAN (MAXVALUE)
   				TABLESPACE ABD02_DATOS
);


/*3.3. Mostrar con un SELECT los tablespaces donde se ha creado todas las tablas, particiones y subparticiones 
(nombre de la tabla, nombre de la partición, nombre de la subpartición, y nombre del tablespace de la tabla o partición o subpartición).*/
SELECT table_name, p.partition_name, sp.subpartition_name, sp.tablespace_name
FROM user_tables t
  LEFT JOIN dba_tab_partitions p
    LEFT JOIN dba_tab_subpartitions sp
    ON  ( (p.partition_name = sp.partition_name)  and (sp.table_owner = 'ABD02' ) )
  ON t.table_name = p.table_name;
/*
3.4. Mostrar con un SELECT las restricciones de integridad de clave primaria de las tablas creadas (nombre de la tabla, nombre de la clave primaria, columna que forma parte de la clave primaria).
*/

SELECT cc.constraint_name , cc.table_name , cc.column_name 
FROM user_cons_columns CC, user_constraints CO
WHERE constraint_type='P';

--3.5. Mostrar con un SELECT las restricciones de integridad de clave ajena (externa) de las tablas creadas (nombre de la tabla, nombre de la clave ajena, columna que forma parte de la clave ajena, y nombre de la clave primaria o clave única a la que apunta). 


SELECT cc.constraint_name , cc.table_name , cc.column_name 
FROM user_cons_columns CC, user_constraints CO
WHERE constraint_type='R';

--3.6. Mostrar con un SELECT las restricciones de integridad de tipo CHECK de las tablas creadas (nombre de la tabla, nombre de la restricción, y condición de la restricción).  

SELECT constraint_name , table_name ,search_condition 
FROM user_constraints 
WHERE constraint_type='C';

