--7. TABLESPACES: tipos y modos

--7.1. Crear un tablespace ABDXX_NOLOCAL, de 256K, no manejado localmente. Justificar los resultados.
CREATE TABLESPACE ABD02_NOLOCAL
DATAFILE 'ABD02_NOLOCAL.DBF' SIZE 256K
EXTENT MANAGEMENT DICTIONARY;


--El tablespace SYSTEM ha sido creado en local. Por lo tanto, no podemos crear un tablespace que no esté manejado localmente.

--7.2. Tablespaces READONLY. Razonar cada resultado obtenido al realizar estas acciones:
--En el tablespace ABDXX_DATOS crear una tabla ABDXX_R de 32KB.

CREATE TABLE ABD02_R(nombre varchar(20))
TABLESPACE ABD02_datos
STORAGE (INITIAL 32k);

--Insertar una fila en la tabla ABDXX_R.

INSERT INTO ABD02_R VALUES (1);

--Poner el tablespace ABDXX_DATOS en modo READONLY.

ALTER TABLESPACE ABD02_DATOS READ ONLY;

--Insertar otra fila en la tabla ABDXX_R. Razonar el resultado obtenido.

INSERT INTO ABD02_R VALUES (2);

--Mostrar con un SELECT el contenido de la tabla ABDXX_R.

SELECT *
FROM ABD02_R;


--Borrar la tabla ABDXX_R. Justificar el comportamiento del sistema.

DROP TABLE ABD02_R;

--Mientras se encuentra en modo solamente de lectura, no permite llevar a cabo la inserción de datos, por ejemplo, pero si la eliminación, como puede comprobarse en este ejercicio.

--Volver a poner el tablespace ABDXX_DATOS en modo READWRITE.

ALTER TABLESPACE ABD02_DATOS READ WRITE;


--7.3. Tablespaces OFFLINE. Justificar los resultados obtenidos al realizar cada una de estas acciones:

--En el tablespace ABDXX_DATOS crear una tabla ABDXX_O de 64KB.

CREATE TABLE ABD02_O(
nombre varchar(50)
)
TABLESPACE ABD02_datos
STORAGE (INITIAL 64k);

--Insertar una fila en la tabla ABDXX_O.

INSERT INTO ABD02_O VALUES (1);

--Poner el tablespace ABDXX_DATOS en modo OFFLINE.

ALTER TABLESPACE ABD02_DATOS OFFLINE;

--Insertar otra fila en la tabla ABDXX_O.

INSERT INTO ABD02_O VALUES (2);

--Mostrar con un SELECT el contenido de la tabla ABDXX_O.

SELECT *
FROM abd02_o;


--Borrar la tabla ABDXX_O.

DROP TABLE ABD02_O;

--Volver a poner ONLINE el tablespace ABDXX_DATOS.

ALTER TABLESPACE ABD02_DATOS ONLINE;

--7.4. Tablespaces UNDO. Responder razonadamente a las siguientes cuestiones:

--Mostrar el tablespace de undo activo en este momento.

SELECT TABLESPACE_NAME, STATUS, CONTENTS
FROM dba_tablespaces
WHERE CONTENTS = 'UNDO' AND STATUS='ONLINE';

--Crear un tablespace de undo ABDXX_UNDO de 256KB.

CREATE UNDO TABLESPACE ABD02_UNDO
DATAFILE 'ABD02_UNDOEJ7.DBF'
SIZE 256 K;


--Crear una tabla ABDXX_U de 32k en el nuevo tablespace ABDXX_UNDO.

CREATE TABLE ABD02_U(nombre varchar(3))
TABLESPACE ABD02_UNDO
STORAGE (INITIAL 32 k);

--Mostrar con un SELECT el nombre de todos los segmentos de rollback de la base de datos, indicando el tablespace en el que están y si están online u offline.

SELECT SEGMENT_NAME, TABLESPACE_NAME, STATUS
FROM dba_rollback_segs;

--¿Cómo se podrían poner online los segmentos de rollback del tablespace ABDXX_UNDO?

--ALTER ROLLBACK SEGMENT NOMBRE_SEGMENTO ONLINE.

ALTER SYSTEM TABLESPACE ABD02_UNDO Online;

ALTER SYSTEM SET UNDO_TABLESPACE=ABD02_UNDO;

--Borrar completamente el tablespace ABDXX_UNDO. Comprobar si es necesario borrar la tabla ABDXX_U (en el caso de existir ésta) y el fichero empleado en la creación del tablespace.
DROP TABLESPACE ABD02_UNDO
INCLUDING CONTENTS AND DATAFILES;
DROP TABLE  ABD02_U;

--7.5. Tablespaces TEMPORALES. Justificar los resultados obtenidos tras realizar cada acción:

--Mostrar con un SELECT el nombre del tablespace temporal por defecto del usuario ABDXX.Anótelo, pues luego deberá recordar cuál era.

SELECT USERNAME, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE
FROM DBA_USERS
WHERE USERNAME='ABD02';

--Crear un tablespace temporal ABDXX_TEMPORAL del menor tamaño posible.
/*Tal y como se explicó en el ejercicio 2.2 sabemos que la mínima extensión posible tiene
que ser de 5 bloques. Por lo tanto, creamos un tablespace temporal con un tamaño de
40K (8K*5 = 40 K).*/

CREATE TEMPORARY TABLESPACE ABD02_TEMPORAL
TEMPFILE 'ABD02_TEMPORAL.DBF'
SIZE 40K REUSE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1K;

--Ponerlo en modo readonly.

--No existe para uno temporal, No se puede poner en modo READ ONLY.

--Ponerlo en modo offline. Si tiene éxito, volver a ponerlo online.

ALTER TABLESPACE ABD02_TEMPORAL OFFLINE;
--Explicar el error y que siempre va a estar online
--¿Cómo se podría establecer como el tablespace temporal por defecto de la base de datos?

ALTER DATABASE
DEFAULT TEMPORARY TABLESPACE ABD02_TEMPORAL;

--Renombrarlo a ABDXX_TEMP1.

ALTER TABLESPACE ABD02_TEMPORAL RENAME TO ABD02_TEMP1;


--Crear una tabla (no temporal) ABDXX_T en dicho tablespace.

CREATE TABLE ABD02_T (nombre varchar(20) )
TABLESPACE ABD02_TEMP1;

--Asignar al usuario ABDXX el tablespace ABDXX_TEMP1 como su tablespace temporal pordefecto.

ALTER USER ABD02 TEMPORARY TABLESPACE ABD02_TEMP1;
select *
from dba_users
where username= 'ABD02';

--Mostrar de nuevo el nombre del tablespace temporal por defecto del usuario ABDXX.

SELECT USERNAME, TEMPORARY_TABLESPACE
FROM DBA_USERS
WHERE USERNAME='ABD02';

--Reasignar al usuario ABDXX su tablespace temporal por defecto original.

--Como recordamos del apartado 1 de este ejercicio el tablespace temporal por defecto original de este usuario era el tablespace ‘TEMP’.

ALTER USER ABD02 TEMPORARY TABLESPACE ADBD_TEMP;

--Borrar por completo de la base de datos el tablespace ABDXX_TEMP1.

DROP TABLESPACE ABD02_TEMP1;
