--8 OPTIMIZACIÓN

--8.1 Mostrar el modo de optimización de consultas de la sesión.
show parameter optimizer_mode;


--8.2 Borrar todas las estadísticas que puedan existir relacionadas con el esquema ABDXX [mediante una invocación del procedimiento DBMS_STATS.delete_schema_stats(…);]

EXECUTE DBMS_STATS.delete_schema_stats('ABD02');

--8.3 Computar las estadísticas de todos los elementos (objetos) del esquema ABDXX [invocación del procedimiento DBMS_UTILITY.analyze_schema(…);].

EXECUTE DBMS_UTILITY.analyze_schema('ABD02', 'COMPUTE');

--8.4 Mostrar con tres SELECT las estadísticas de las tablas, las estadísticas de las columnas de las tablas, y las estadísticas de los índices.

select *
from dba_tables;

select *
from dba_tab_col_statistics;

select *
from dba_indexes;

--8.5 Mostrar con un SELECT los índices definidos sobre las tablas ABDXX_ONG y ABDXX_PROYECTO (nombre de la tabla, nombre del índice, tipo de índice).

select table_name, index_name, index_type
from dba_indexes
where table_name= 'ABD0 2_ONG' or table_name='ABD02_PROYECTO';

--8.6 Activar la autotraza para mostrar el plan de ejecución (sin estadísticas) de las sentencias SELECT que ejecutará en los siguientes ejercicios. Quizá deba desactivarla en ocasiones, por ejemplo para ejecutar sentencias de creación o destrucción de elementos del esquema.
set autotrace on explain;

--8.7 Optimizar consultas. Para ello, a) ejecutar cada consulta indicada; b) mostrar y analizar su plan de ejecución; c) crear los índices necesarios (en el tablespace de índices) para optimizarla, d) volver a mostrar el plan optimizado de la consulta; y e) justificar los resultados.
  --A  Mejorar el rendimiento de la siguiente consulta, que muestra las ONG de Murcia.

  create index ej8a
on abd02_ong(provincia)
tablespace abd02_indices;

Explain plan for
SELECT codigo, nombre, email, telf
FROM ABD02_ONG
WHERE provincia='Murcia';

  SELECT plan_table_output
		FROM TABLE(DBMS_XPLAN.DISPLAY());




  --B  Optimizar la siguiente consulta, que muestra las ONG de Murcia cuyo campo de acción es 'COOPERACIÓN PARA EL DESARROLLO'.

  create  index ej8b
  		on abd02_ong(provincia, campo)
  		tablespace abd02_indices ;

        explain plan for
        select codigo, nombre, email, telf
        from abd02_ong
        where provincia='Murcia' and campo='COOPERACIÓN PARA EL DESARROLLO';


          SELECT plan_table_output
  		FROM TABLE(DBMS_XPLAN.DISPLAY());


  --C Mejorar el rendimiento de esta consulta, que muestra las ONG de Murcia cuyo campo de acción es 'COOPERACIÓN PARA EL DESARROLLO' y que tienen proyectos en ETIOPÍA.
  create index ej8c
        on abd02_proyecto(ong,pais)
        tablespace abd02_indices;

  EXPLAIN PLAN FOR
  SELECT codigo, nombre, email, telf
  FROM ABD02_ONG O
  WHERE O.provincia='Murcia'AND O.campo='COOPERACIÓN PARA EL DESARROLLO'
   AND O.codigo IN (SELECT ong FROM ABD02_PROYECTO P
   WHERE P.pais='ETIOPIA');

          SELECT plan_table_output
  		FROM TABLE(DBMS_XPLAN.DISPLAY());


--8.8 Asegurarse de que la autotraza queda desactivada.

set autotrace off;
--8.9 Eliminar los índices creados en este ejercicio.
  drop index ej8a;
  drop index ej8b;
  drop index ej8c;
--8.10  Volver a mostrar con un SELECT los índices definidos sobre las tablas ABDXX_ONG y
--ABDXX_PROYECTO (nombre de la tabla, nombre del índice, tipo de índice), y comprobar
--que han quedado los que había antes del ejercicio 8.

select table_name, index_name, index_type
from dba_indexes
where table_name= 'ABD02_ONG' or table_name='ABD02_PROYECTO';
