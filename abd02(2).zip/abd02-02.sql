--2. TABLESPACES

--2.1.Crear un tablespace permanente llamado ABDXX_DATOS, usando el fichero ‘ABDXX_DATOS1.DBF’, con un tamaño inicial de 256 KB, que pueda crecer automáticamente hasta un tamaño máximo de 1MB, con gestión manual del espacio de los segmentos, y con un valor por defecto de 32KB para todas las extensiones de todos los objetos que se creen en él. Importante: Si durante la realización de los ejercicios posteriores de esta práctica el tablespace se llenará, justo en ese momento (no ahora), se deberá añadir al tablespace un segundo fichero ‘ABDXX_DATOS2.DBF’ con las mismas características de espacio que el primero. 

CREATE TABLESPACE ABD02_DATOS
DATAFILE 'ABD02_DATOS1.dbf' SIZE 256K REUSE
AUTOEXTEND ON MAXSIZE 1M 
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 32K
SEGMENT SPACE MANAGEMENT MANUAL;

--2.2.Crear un tablespace permanente para los índices llamado ABDXX_INDICES, usando el fichero ‘ABDXX_INDICES1.DBF’, con un tamaño inicial de 256KB que pueda crecer automáticamente hasta un tamaño máximo de 512KB, con extensiones del menor tamaño posible (justificar dicho tamaño) manejadas localmente, y con gestión automática del espacio de los segmentos. Importante: Si durante la realización de la práctica el tablespace se llenará, justo en ese momento, se deberá añadir al tablespace un segundo fichero ‘ABDXX_INDICES2.DBF’ con iguales características de espacio que el primero. 

CREATE TABLESPACE ABD02_INDICES
DATAFILE ‘ABD02_INDICES1.dbf’ SIZE 256K 
AUTOEXTEND ON MAXSIZE 512K
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 8K
SEGMENT SPACE MANAGEMENT AUTO;

--Al intentarlo la primera vez, se mostró un error como el que se aprecia en la imagen anterior.
--Como se conoce que el tamaño de un bloque es de 8K, pues al necesitar 5 bloques, el tamaño que se necesita es de 40K. ( Se sabe que el tamaño es de 8k, por los primeros ejercicios realizados).

create tablespace ABD02_INDICES
  DATAFILE 'ABD02_INDICES1.dbf' size 256K reuse 
  autoextend on maxsize 512K
  extent management local uniform size 40K
  segment space management auto;


--2.3.Mostrar con un SELECT los dos tablespaces creados (nombre del tablespace, tipo de contenido, tamaño de bloque, tamaño de la extensión inicial, tamaño de la extensión siguiente, porcentaje de incremento de las siguientes extensiones, forma de manejo de las extensiones, y forma de manejo del espacio de los segmentos). 

Select TABLESPACE_NAME, CONTENTS, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT,PCT_INCREASE, EXTENT_MANAGEMENT, ALLOCATION_TYPE
from dba_tablespaces
where ( TABLESPACE_NAME='ABD02_DATOS' OR TABLESPACE_NAME='ABD02_INDICES' );


--2.4.Mostrar con un SELECT los ficheros de los dos tablespaces creados (nombre del tablespace, nombre del fichero, tamaño inicial, si/no puede crecer automáticamente, y tamaño máximo).

--Para listar los parámetros solicitados usamos “dba_data_files” que contiene información relativa a los ficheros de la base de datos. Seleccionamos los atributos que se se solicitan  y por último filtramos los resultados para los ficheros de los tablespaces creados en los apartados anteriores.

Select TABLESPACE_NAME, FILE_NAME,BYTES,AUTOEXTENSIBLE, MAXBYTES
from dba_data_files
where  ( TABLESPACE_NAME='ABD02_DATOS' OR TABLESPACE_NAME='ABD02_INDICES' );


--2.5.Mostrar con un SELECT el espacio libre de los dos tablespaces creados (nombre del tablespace, espacio libre). Justificar el resultado. 

--Estudiando el espacio libre de la base de datos, nos muestra el espacio libre de cada tablespace. Ha sido cuestión de definir en la consulta que tablespaces son los que queremos mostrar, en nuestro caso, los dos que hemos creado. 

Select TABLESPACE_NAME, bytes/1024 "Espacio Libre (MB)"
from dba_free_space
where  ( TABLESPACE_NAME='ABD02_DATOS' OR TABLESPACE_NAME='ABD02_INDICES' );


--2.6.Asignar por defecto el tablespace ABDXX_DATOS a su usuario ABDXX

--Vamos a mirar antes de modificar que tablespace tenemos asignado por defecto, para ello usamos la siguiente consulta:

SELECT *
FROM dba_users
WHERE username='ABD02';


ALTER USER ABD02 DEFAULT TABLESPACE ABD02_DATOS;
--Con este mensaje se confirma que la operación ha sido satisfactoria pero podemos comprobar con la siguiente sentencia que para el usuario ‘ABD02’ su tablespace por defecto es ‘ABD02_DATOS’:

SELECT *
FROM dba_users
WHERE username='ABD02';





