/*6. VISTAS MATERIALIZADAS
6.1.Crear una vista materializada llamada ABDXX_VM_ONG que muestre cu�ntos socios colaboradores tiene cada ONG (la vista ha de tener dos columnas: ONG y num_socios), con carga inmediata y refresco r�pido (incremental) al hacer COMMIT.
Crear la vista materializada.*/

CREATE MATERIALIZED VIEW LOG ON ABD02_COLABORACION with ROWID, SEQUENCE, PRIMARY KEY INCLUDING NEW VALUES;

CREATE MATERIALIZED VIEW ABD02_VM_ONG
BUILD IMMEDIATE
REFRESH FAST ON COMMIT
AS SELECT ong ONG, COUNT(*) CUANTOS_SOCIOS
FROM ABD02_COLABORACION
GROUP BY ong;

--Mostrar con un SELECT el contenido de la vista.
select *
from abd02_vm_ong;

/*Si es necesario, refrescar los datos de la vista.
	No es necesario, ya esta cargado*/
--Volver a mostrar con un SELECT el contenido de la vista.
select *
from abd02_vm_ong;

--Insertar una fila en la tabla ABDXX_COLABORACION.
INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
	VALUES(8,'55555555A','04/06/2007',50);
--Si es necesario, volver a refrescar los datos de la vista.
--	S�, es necesario ya que hemos modificado la tabla
--Volver a mostrar con un SELECT el contenido de la vista.

select *
from abd02_vm_ong;


--Borrar la fila insertada en la tabla ABDXX_COLABORACION.
 delete from ABD02_COLABORACION
 where socio='55555555A' and ong=8;

--Si es necesario, volver a refrescar los datos de la vista.
--	S�, es necesario ya que hemos modificado la tabla

--Volver a mostrar con un SELECT el contenido de la vista.
select *
from abd02_vm_ong;

--6.2.Eliminar la vista y repetir el ejercicio creando la misma vista materializada pero con carga diferida y refresco completo bajo demanda.

 	drop materialized view abd02_vm_ong;
DROP MATERIALIZED VIEW LOG ON ABD02_COLABORACION;
materialized view ABD02_VM_ONG borrado.
materialized view log ABD02_COLABORACION borrado.

--Crear la vista materializada.

CREATE MATERIALIZED VIEW ABD02_VM_ONG
	TABLESPACE ABD02_DATOS
	BUILD DEFERRED
	REFRESH COMPLETE ON DEMAND
	AS SELECT ong ONG, COUNT(*) CUANTOS_SOCIOS
FROM ABD02_COLABORACION
GROUP BY ong;

   	 materialized view ABD02_VM_ONG creado.

--Mostrar con un SELECT el contenido de la vista.
select *
from abd02_vm_ong;

--Si es necesario, refrescar los datos de la vista.
--	S�, es necesario refrescar para mostrar los datos, para ello llamando a la funcion:
execute DBMS_MVIEW.REFRESH('ABD02_VM_ONG','c');

--Volver a mostrar con un SELECT el contenido de la vista
select  *
from abd02_vm_ong;

--Insertar una fila en la tabla ABDXX_COLABORACION.
INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
	VALUES(8,'55555555A','04/06/2007',50);

--Si es necesario, volver a refrescar los datos de la vista.
--S�, es necesario refrescar para mostrar los datos, para ello llamando a la funcion:
execute DBMS_MVIEW.REFRESH('ABD02_VM_ONG','c');

--Volver a mostrar con un SELECT el contenido de la vista.
SELECT *
FROM  abd02_vm_ong;


--Borrar la fila insertada en la tabla ABDXX_COLABORACION.
 delete from ABD02_COLABORACION
 where socio='55555555A' and ong=8;

--Si es necesario, volver a refrescar los datos de la vista.
--S�, es necesario refrescar para mostrar los datos, para ello llamando a la funcion:
execute DBMS_MVIEW.REFRESH('ABD02_VM_ONG','c');
--Volver a mostrar con un SELECT el contenido de la vista. 

SELECT *
FROM  abd02_vm_ong;

--6.3.Destruir la vista y repetir el ejercicio completo, creando la misma vista materializada pero con carga inmediata y refresco completo al hacer COMMIT. 

 drop materialized view abd02_vm_ong;
--Crear la vista materializada.
CREATE MATERIALIZED VIEW LOG ON ABD02_COLABORACION with ROWID, SEQUENCE, PRIMARY KEY INCLUDING NEW VALUES;


	CREATE MATERIALIZED VIEW ABD02_VM_ONG
	TABLESPACE ABD02_DATOS
	BUILD IMMEDIATE
	REFRESH COMPLETE ON COMMIT
	AS SELECT ong ONG, COUNT(*) CUANTOS_SOCIOS
FROM ABD02_COLABORACION
GROUP BY ong;

--Mostrar con un SELECT el contenido de la vista.
SELECT *
FROM  abd02_vm_ong;

--Si es necesario, refrescar los datos de la vista.
--	No es necesario, ya esta cargado
--Volver a mostrar con un SELECT el contenido de la vista.
SELECT *
FROM  abd02_vm_ong;

--Insertar una fila en la tabla ABDXX_COLABORACION.
INSERT INTO ABD02_COLABORACION(ong, socio, fechaalta, cuota)
	VALUES(8,'55555555A','04/06/2007',50);


--Si es necesario, volver a refrescar los datos de la vista.
--S�, es necesario llamar a commit para actualizar.
commit;
--Volver a mostrar con un SELECT el contenido de la vista.
SELECT *
FROM  abd02_vm_ong;

-Borrar la fila insertada en la tabla ABDXX_COLABORACION.
 delete from ABD02_COLABORACION
 where socio='55555555A' and ong=8;

--Si es necesario, volver a refrescar los datos de la vista.
	--S�, es necesario llamar a commit para actualizar.
commit;
--Volver a mostrar con un SELECT el contenido de la vista. 

SELECT *
FROM  abd02_vm_ong;



