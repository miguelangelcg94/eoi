--1. CONSULTAS DEL DICCIONARIO DE LA BASE DE DATOS 

--1.1.Mostrar con un SELECT el tamaño total en MB de la SGA (tamaño). 

--El tamaño total de la SGA se obtiene sumando todos los elementos de memoria que la componen y se divide el resultado para obtener el tamaño en M.

SELECT sum(value)/1024/1024 "TOTAL SGA (MB)" FROM v$sga;

--1.2.Mostrar el tamaño del bloque de la base de datos, el nombre de la base de datos, y el nombre de la instancia a la que se está conectado. 


show parameter db_block_size;
show parameter db_name;                                                                                  
show parameter instance_name;


--Como alternativa podemos hacerlo en una sola consulta, usando la vista dinámica de parámetros del sistema, donde tenemos toda esta información buscado los nombres de las filas concretas.

SELECT name parametro, value valor 
FROM v$system_parameter 
WHERE name in ('db_block_size','db_name','instance_name');


--1.3.Mostrar con un SELECT tres parámetros de inicialización de la base de datos que estén relacionados con el tamaño de la SGA (nombre del parámetro, descripción y valor). Justificar en qué afecta cada uno de ellos al tamaño de la SGA. 

select name, description, value 
from v$parameter
where name=’sga_max_size’ or name=’shared_pool_size’ or name=’large_pool_size’;

--1.4.Mostrar con un SELECT las 3 últimas sentencias SQL cargadas en la shared-pool (texto de la sentencia, fecha y hora en que se cargó). 

--Mostramos las últimas tres sentencias ejecutadas en el SQL_AREA, el cual se encuentra dentro de la SHARED_POOL.
select * 
from ( select sql_text,  first_load_time from  v$sqlarea order by first_load_time desc ) 
where rownum <4; 

--1.5.Mostrar con una sola sentencia SELECT

 --a) los ficheros de datos y los tablespaces a los que están asociados, b) los ficheros de control, y c) los ficheros de redo de la base de datos. La primera columna indicará el tipo de fichero (tipo de fichero –DATAFILE|CONTROLFILE|REDOFILE-, nombre del fichero, y nombre del tablespace si es un fichero de datos). 

select 'CONTROLFILE' tipoFichero, name, null tablespace 
from v$controlfile  
UNION   
select 'DATAFILE' tipoFichero, file_name, tablespace_name from dba_data_files  
UNION
select 'REDOFILE' tipoFichero, member, null tablespace from v$logfile;

--1.6.Mostrar con un SELECT los tablespaces de rollback (undo) que están definidos en la base de datos (nombre del tablespace, tipo de contenido). 
select tablespace_name, contents
from dba_tablespaces
where contents=’UNDO’;





