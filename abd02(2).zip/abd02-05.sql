/*5.1 Mover �ndices a otro tablespace.  Mostrar con un SELECT el tablespace en el que se ha creado cada uno de los 
�ndices de ejercicios anteriores (nombre de la tabla, del �ndice y del tablespace del �ndice). 
Mover dichos �ndices (todos) al tablespace ABDXX_INDICES.  Mostrar con el mismo SELECT que, efectivamente, han cambiado de tablespace. 
*/
select TABLE_NAME, INDEX_NAME, TABLESPACE_NAME
from DBA_INDEXES
where table_owner= 'ABD02';

--Mover dichos �ndices.

--Cuota en Tablespace ABD02_INDICES.
ALTER USER abd02
	QUOTA UNLIMITED
ON ABD02_INDICES;

ALTER INDEX ACCION_PK  REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX COLABORACION_PK  REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX ONG_PK REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX CLAVE_UNIQUE REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX PARTICIPACION_PK REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX PROYECTO_PK REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX SOCIO_PK REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX TRABAJADOR_PK REBUILD TABLESPACE ABD02_INDICES;

ALTER INDEX ID02_PAP REBUILD TABLESPACE ABD02_INDICES;

ALTER TABLE ABD02_SOCIO MOVE TABLESPACE ABD02_INDICES;

--Mostrar que efectivamente se movieron todos.
select TABLE_NAME, INDEX_NAME, TABLESPACE_NAME
from DBA_INDEXES
where table_owner= 'ABD02';

--5.2

/**En ABDXX_SOCIO, crear un �ndice llamado ABDXX_SOCIO_NOMBRE sobre la columna nombre.*/
create index ABD02_SOCIO_NOMBRE
ON ABD02_SOCIO(nombre)
TABLESPACE ABD02_INDICES;

/*En ABDXX_TRABAJADOR, un �ndice llamado ABDXX_TRABAJADOR_FECHAINGRESO, de tipo global, con dos particiones por rango de la columna fechaingreso.  */

create index ABD02_TRABAJADOR_FECHAINGRESO
	ON ABD02_TRABAJADOR(fechaingreso)
		GLOBAL PARTITION BY RANGE (fechaingreso)
			(
				PARTITION p1_ABD02_TRABAJADOR_INGRESO VALUES LESS THAN(TO_DATE('01/01/2012' ,'dd/mm/yyyy'))
  					TABLESPACE ABD02_INDICES,
  			 PARTITION	p2_ABD02_TRABAJADOR_INGRESO VALUES LESS THAN (MAXVALUE)
   					TABLESPACE ABD02_INDICES);

/*En ABDXX_TRABAJADOR, un �ndice llamado ABDXX_TRABAJADOR_ESVOLUNTARIO, de tipo mapa de bits (bitmap) sobre la columna esvoluntario. */
ALTER TABLESPACE ABD02_INDICES ADD  DATAFILE 'ABD02_INDICES2.dbf'
  size 256K reuse 
  autoextend on maxsize 512K;

CREATE  BITMAP INDEX ABD02_TRABAJADOR_ESVOLUNTARIO
ON ABD02_TRABAJADOR(esVoluntario)
LOCAL TABLESPACE ABD02_INDICES;

/*En ABDXX_COLABORACION, un �ndice llamado ABDXX_COLABORACION_FECHAALTA, de tipo particionado local, sobre la columna fechaalta.*/
CREATE INDEX ABD02_COLABORACION_FECHAALTA
ON ABD02_COLABORACION(fechaalta)
LOCAL TABLESPACE ABD02_INDICES;

/*5.3.Visualizar con un SELECT las particiones del �ndice ABDXX_TRABAJADOR_FECHAINGRESO (nombre del �ndice, nombre de la partici�n y valor m�ximo de la partici�n). */
select index_name as nombre_indice, partition_name as nombre_particion, High_value_length as valor_maximo_particion
from dba_ind_partitions
where index_owner= 'ABD02' and index_name =  'ABD02_TRABAJADOR_FECHAINGRESO';

--5.4

select B.index_name, B.partition_name, A.subpartition_name, B.high_value_length
from
((
    select *
    from dba_ind_subpartitions
    where index_owner= 'ABD02' and index_name = 'ABD02_COLABORACION_FECHAALTA'
  ) A
 
    left outer join  
 
    (select *
    from dba_ind_partitions
    where index_owner= 'ABD02' and index_name = 'ABD02_COLABORACION_FECHAALTA'
  ) B on A.index_name=B.index_name and A.partition_name=B.partition_name  )
;


                    
          
                  
                  
                  









