--9 USUARIOS, PERFILES, PERMISOS Y ROLES
  --9.1.Conectar como usuario ABDXX, crear un nuevo usuario autentificado por la base de datos, con las siguientes especificaciones:
--ABDXX_OPERARIO: Su clave inicial es 0P3R4R102. Sin cuota en su tablespace por defectoABDXX_DATOS, con espacio ilimitado en ABDXX_INDICES, y cuota 0 en el resto. Su tablespace temporal ha de ser uno de los tablespaces temporales ya definidos en la base de datos. 

  
  CREATE USER ABD02_OPERARIO
	IDENTIFIED BY "0P3R4R10"
	DEFAULT TABLESPACE ABD02_DATOS
	TEMPORARY TABLESPACE ADBD_TEMP
	QUOTA UNLIMITED ON ABD02_INDICES;
  
  --9.2 Mostrar con un SELECT los tablespaces por defecto y temporales de ABDXX y ABDXX_OPERARIO (usuario, nombre de su tablespace por defecto, nombre de su tablespace temporal). 
	SELECT USERNAME, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE
	FROM DBA_USERS
	WHERE (username= 'ABD02' or username='ABD02_OPERARIO');
  
  --9.3.Mostrar con un SELECT las cuotas de espacio en los tablespaces ABDXX_DATOS y ABDXX_INDICES de ABDXX y de ABDXX_OPERARIO (usuario, tablespace, bytes, maxbytes). 
	SELECT USERNAME, TABLESPACE_NAME, BYTES, MAX_BYTES
	FROM DBA_TS_QUOTAS
	WHERE USERNAME= 'ABD02' OR USERNAME='ABD02_OPERARIO';
  
 --9.4 Permitir que el usuario ABDXX_OPERARIO pueda ocupar hasta 2M de espacio en el tablespace ABDXX_DATOS. Y volver a mostrar las cuotas para ambos usuarios. 
  ALTER USER ABD02_OPERARIO quota 2M on ABD02_DATOS;
  SELECT USERNAME, TABLESPACE_NAME, BYTES, MAX_BYTES
	FROM DBA_TS_QUOTAS
	WHERE USERNAME= 'ABD02' OR USERNAME='ABD02_OPERARIO';
  --9.5 9.5.Crear un perfil denominado ABDXX_PERFIL_OPERARIO, que garanticen estas especificaciones:
/**Las contraseñas de ABDXX_OPERARIO expirarán a los 30 días.
ABDXX_OPERARIO puede iniciar simultáneamente hasta 2 conexiones a la base de datos.
ABDXX_OPERARIO tiene limitado a 10 minutos el tiempo de inactividad de sus sesiones (pasado ese tiempo se cerrará automáticamente la sesión).
La cuenta de ABDXX_OPERARIO se bloqueará durante 3 días en el caso de superar los 4 intentos consecutivos fallidos de conexión.*/


CREATE PROFILE ABD02_PERFIL_OPERARIO LIMIT
SESSIONS_PER_USER 2
IDLE_TIME 10
FAILED_LOGIN_ATTEMPTS 4
PASSWORD_LIFE_TIME 30
PASSWORD_LOCK_TIME 3;

--9.6 Asignar el perfil al usuario creado.
ALTER USER ABD02_OPERARIO
PROFILE ABD02_PERFIL_OPERARIO;

--9.7.Mostrar con un SELECT el perfil creado en la base de datos y qué límites de recursos establece (nombre del perfil, nombre del recurso limitado, tipo del recurso, y límite). Se recomienda que muestre sólo los límites fijados, y no todos.

-- perfil creado, nombre del perfil, nombre del recurso limitado, tipo del recurso y limite.
SELECT *
from dba_profiles
where profile= 'ABD02_PERFIL_OPERARIO' and not limit='DEFAULT';

--9.8 Conceder a ABDXX_OPERARIO el permiso para consultar la tabla ABDXX_ONG. 
GRANT SELECT ON ABD02_ONG
TO ABD02_OPERARIO;
--9.9 Crear el rol denominado ABDXX_ROL_OPERARIO. Conceder a dicho rol los privilegios adecuados sobre elementos del esquema (indicados a continuación), y asignar el rol al usuarios ABDXX_OPERARIO, de forma que se cumplan los siguientes requisitos:
--Primero se crea el rol.
CREATE ROLE ABD02_ROL_OPERARIO NOT IDENTIFIED;
--ABDXX_OPERARIO puede consultar cualquier tabla del esquema de las ONG. Salvo la columna sueldo de TRABAJADOR.
--1 Consultar cualquier tabla del esquema menos sueldo de TRABAJADOR.
GRANT select 
ON ABD02_accion
TO ABD02_ROL_OPERARIO;

GRANT select
ON ABD02_colaboracion
TO ABD02_ROL_OPERARIO;

GRANT select
ON ABD02_ong
TO ABD02_ROL_OPERARIO;

GRANT select 
ON ABD02_participacion
TO ABD02_ROL_OPERARIO;

GRANT select 
ON ABD02_proyecto
TO ABD02_ROL_OPERARIO;

GRANT select 
ON ABD02_socio
TO ABD02_ROL_OPERARIO;

--Como no se pueden indicar columnas junto con el privilegio Select. La solución, para que solo puede consultar las columnas de la tabla trabajador que se indica. Es crear una vista, que contenga todas las columnas, menos la columna “sueldo”.

CREATE VIEW vistaejer99 AS
	select dni, nombre, ong, fechaingreso, esvoluntario, nacimiento, profesion, horas
	from abd02_trabajador;


GRANT select 
ON vistaejer99
TO ABD02_ROL_OPERARIO;



--Puede insertar filas en cualquier tabla, salvo en ABDXX_SOCIO.
--2 Insertar filas en cualquiera, menos en ABD02_SOCIO.

GRANT insert
ON ABD02_accion
TO ABD02_ROL_OPERARIO;

GRANT insert 
ON ABD02_colaboracion
TO ABD02_ROL_OPERARIO;

GRANT insert 
ON ABD02_ong
TO ABD02_ROL_OPERARIO;


GRANT insert 
ON ABD02_participacion
TO ABD02_ROL_OPERARIO;


GRANT insert 
ON ABD02_proyecto
TO ABD02_ROL_OPERARIO;


GRANT insert 
ON ABD02_trabajador
TO ABD02_ROL_OPERARIO;



--Puede actualizar (cambiar valores de) filas en cualquier tabla del esquema, excepto para las columnas fechaalta y cuota de la tabla ABDXX_COLABORACION.
--3 Actualizar valores en cualquiera, menos columnas fechaalta y cuota de la tabla ABD02_COLABORACION.

GRANT UPDATE
ON ABD02_accion
TO ABD02_ROL_OPERARIO;

GRANT UPDATE (ong, socio)
ON ABD02_colaboracion
TO ABD02_ROL_OPERARIO;

GRANT UPDATE
ON ABD02_ong
TO ABD02_ROL_OPERARIO;

GRANT UPDATE
ON ABD02_participacion
TO ABD02_ROL_OPERARIO;

GRANT UPDATE
ON ABD02_proyecto
TO ABD02_ROL_OPERARIO;

GRANT UPDATE
ON ABD02_socio
TO ABD02_ROL_OPERARIO;

GRANT UPDATE
ON ABD02_trabajador
TO ABD02_ROL_OPERARIO;

--Puede eliminar filas de cualquier tabla salvo para la tabla ABDXX_ONG. Primero se crea el rol.
--4 ELIMINAR FILAS DE CUALQUIER MENOS EN ABD02_ONG. accion, colaboracion, ong, participacion, proyecto, socio, trabajador.
GRANT delete 
ON ABD02_accion
TO ABD02_ROL_OPERARIO;

GRANT delete 
ON ABD02_colaboracion
TO ABD02_ROL_OPERARIO;

GRANT delete
ON ABD02_participacion
TO ABD02_ROL_OPERARIO;

GRANT delete 
ON ABD02_proyecto
TO ABD02_ROL_OPERARIO;

GRANT delete
ON ABD02_socio
TO ABD02_ROL_OPERARIO;

GRANT delete
ON ABD02_trabajador
TO ABD02_ROL_OPERARIO;


--Asignar rol usuario grant rol to usuario)

grant ABD02_ROL_OPERARIO to ABD02_OPERARIO;

--9.10 Mostrar con un SELECT los permisos sobre tablas concedidos a roles (rol, tabla, privilegio), de forma ordenada por rol, tabla y privilegio.

SELECT a.privilege Privilegio_Sistema, b.privilege Privilegio_Objeto, b.Table_name
FROM (select privilege from USER_SYS_PRIVS) a
FULL OUTER JOIN (select privilege, table_name from USER_TAB_PRIVS) b ON a.privilege = b.privilege;

--9.11 Conectar a la base de datos con el usuario ABDXX_OPERARIO. Solucione los posibles problemas que puedan surgir, y explique lo que ha pasado. Una vez que esté conectado correctamente...
--Para solucionar el problema, que podía surgir:
GRANT CREATE SESSION TO ABD02_OPERARIO;
--1 Visualizar los roles activos que tiene el usuario en esta sesión (nombre del rol). 
SELECT ROLE 
FROM SESSION_ROLES;


--2 Mostrar los privilegios de objeto y de sistema obtenidos directamente y no a través de roles, que posee el usuario (nombre del privilegio, tabla [o null, si es de sistema]). 

SELECT a.privilege Privilegio_Sistema, b.privilege Privilegio_Objeto, b.Table_name
FROM (select privilege from USER_SYS_PRIVS) a
FULL OUTER JOIN (select privilege, table_name from USER_TAB_PRIVS) b ON a.privilege = b.privilege;



--3 Listar con SELECT el nombre de las ONG con sede en Murcia, su email y el número de socios colaboradores que tienen, siempre que tengan al menos 3 colaboradores, ordenado por nombre de ONG. (columnas: nombre, email, total_colaboradores). Mostrar el resultado tras la ejecución y comentar. 

SELECT nombre, email, total_colaboradores
FROM ABD02.ABD02_ONG JOIN  
                      (SELECT ong , COUNT(*) total_colaboradores
                            FROM ABD02.ABD02_COLABORACION
                              GROUP BY ong)
                                                  on codigo = ONG
WHERE provincia = 'Murcia' and total_colaboradores > = 3
order by nombre;



--4 Obtener con SELECT el nombre de cada trabajador, profesión y sueldo siempre que haya participado en más de 3 acciones distintas. (columnas: nombre, profesión, sueldo). Listar por orden alfabético de sus nombres. Mostrar lo que aparece en pantalla tras la ejecución y explicar.

SELECT nombre, profesion, sueldo
FROM ABD02.ABD02_trabajador JOIN  
                      (SELECT trabajador, COUNT(*) participa_accion
                            FROM ABD02.ABD02_participacion
                              GROUP BY trabajador)
                                                  on dni = trabajador
WHERE participa_accion > = 3
order by nombre;

--El problema surge, porque el usuario ‘ABD02_OPERARIO’ no tiene privilegios suficientes sobre la columna sueldo de la tabla “TRABAJADOR”, y por tanto no puede consultarla. Como alternativa, lo que podría hacerse es hacer la misma consulta anterior pero sobre la vista (esta vista tiene todas las columnas menos la de sueldo). Sobre esta vista se puede realizar la consulta, porque hay privilegios, pero no se podría consultar la columna sueldo.

--Un ejemplo de lo anterior sería:

SELECT nombre, profesion
FROM ABD02.vistaejer99 JOIN  
                      (SELECT trabajador, COUNT(*) participa_accion
                            FROM ABD02.ABD02_participacion
                              GROUP BY trabajador)
                                                  on dni = trabajador
WHERE participa_accion > = 3
order by nombre;

--5 Modificar la cuota de un socio (elija uno) de cierta ONG (elija una) que desea aportar 50€ más al mes a partir de este momento. Mostrar lo que aparece en pantalla tras la ejecución y razonar.

UPDATE abd02.ABD02_COLABORACION SET
abd02.ABD02_COLABORACION.cuota= abd02.ABD02_COLABORACION.cuota + 50 
WHERE abd02.ABD02_COLABORACION.ong = '8' AND abd02.ABD02_COLABORACION.socio= '10101010A';

--6 Cambiar el teléfono de una ONG (elija una cualquiera). Mostrar lo que aparece en pantalla tras la ejecución y comentar.
	UPDATE ABD02.ABD02_ONG SET
ABD02.ABD02_ONG.telf='968454545'
WHERE ABD02.ABD02_ONG.codigo='8';



--7 Registrar la nueva colaboración de un socio (elija uno) con una ONG (elija una) indicando la fecha actual (del sistema) como fecha de alta y una cuota consecuente con las cuotas que el mismo socio ya aporta a otras ONG. Mostrar lo que aparece en pantalla tras la ejecución y comentar.

--Como puede verse, se utiliza: “Select sysdate from dual”, para obtener la fecha actual del momento de la inserción. De ese modo, cuando la nueva colaboración tendrá esa fecha. Para que la cuota sea consecuente con el resto de aportaciones realizadas por ese socio al resto de ong’s, se decidió obtener la media de todas las aportaciones realizadas por ese socio. Para ello, se utilizó: 

select AVG(cuota)
from abd02.abd02_colaboracion
where abd02.abd02_colaboracion.socio = '10101010A';


--Así, la cuota que se introduce es consecuente con sus demás aportaciones.

insert into abd02.abd02_colaboracion values (4,'10101010A',(select sysdate from dual),( select AVG(cuota)
from abd02.abd02_colaboracion
where abd02.abd02_colaboracion.socio = '10101010A'));



--9.12 Por último, eliminar de la base de datos el usuario, perfil y rol con los que ha trabajado en este ejercicio 9. 
--Para poder eliminar el  usuario debemos de cerrar sesión, ya que no es posible hacer esto estando el usuario conectado.
drop role ABD02_ROL_OPERARIO CASCADE;
drop profile ABD02_PERFIL_OPERARIO CASCADE ;
drop user ABD02_OPERARIO cascade;


  
